function validateForm(form){
 let valid=true;
 form.querySelectorAll("[required]").forEach(el=>{
  const value=el.value.trim();let ok=!!value;
  if(el.type==="email")ok=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  if(el.name==="phone")ok=/^[6-9]\d{9}$/.test(value);
  if(el.name==="password")ok=value.length>=6;
  if(el.name==="confirmPassword"){const p=form.querySelector('[name="password"]');ok=!!p&&value===p.value}
  if(el.type==="date"&&value){const d=new Date(value+"T00:00:00");ok=!Number.isNaN(d.getTime())}
  el.classList.toggle("is-invalid",!ok);valid=valid&&ok;
 });
 return valid;
}
document.addEventListener("input",e=>{if(e.target.matches(".form-control,.form-select"))e.target.classList.remove("is-invalid")});
