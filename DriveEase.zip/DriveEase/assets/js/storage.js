/* Demo data layer: LocalStorage only. Not secure authentication or production persistence. */
const DriveStore = (() => {
 const defaults = {
  cars:[
   {id:1,name:"BMW 3 Series",type:"Luxury Sedan",category:"Sedan",price:4499,seats:5,transmission:"Automatic",fuel:"Petrol",image:"https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=1000&q=85",status:"Available",description:"A refined executive sedan with a confident drive."},
   {id:2,name:"Mercedes-Benz C-Class",type:"Premium Sedan",category:"Sedan",price:5299,seats:5,transmission:"Automatic",fuel:"Petrol",image:"https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=1000&q=85",status:"Available",description:"Elegant comfort with premium technology."},
   {id:3,name:"Porsche 718 Cayman",type:"Sports Coupe",category:"Sports",price:8999,seats:2,transmission:"Automatic",fuel:"Petrol",image:"https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1000&q=85",status:"Available",description:"A thrilling sports car made for open roads."},
   {id:4,name:"Range Rover Evoque",type:"Luxury SUV",category:"SUV",price:6999,seats:5,transmission:"Automatic",fuel:"Diesel",image:"https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=1000&q=85",status:"Available",description:"Versatile luxury for city and weekend escapes."},
   {id:5,name:"Hyundai Creta",type:"Compact SUV",category:"SUV",price:2499,seats:5,transmission:"Manual",fuel:"Petrol",image:"https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=1000&q=85",status:"Available",description:"Comfortable, practical and ready for every day."},
   {id:6,name:"Audi A6",type:"Executive Sedan",category:"Sedan",price:5999,seats:5,transmission:"Automatic",fuel:"Diesel",image:"https://images.unsplash.com/photo-1603584173870-7f23f154d5b4?auto=format&fit=crop&w=1000&q=85",status:"Available",description:"A premium cabin with effortless performance."}
  ], bookings:[], customers:[]
 };
 function get(key){let val=localStorage.getItem("driveease_"+key);if(val===null){localStorage.setItem("driveease_"+key,JSON.stringify(defaults[key]||[]));return structuredClone(defaults[key]||[])}try{return JSON.parse(val)}catch{return defaults[key]||[]}}
 function set(key,val){localStorage.setItem("driveease_"+key,JSON.stringify(val));return val}
 function user(){try{return JSON.parse(localStorage.getItem("driveease_user"))}catch{return null}}
 function setUser(u){localStorage.setItem("driveease_user",JSON.stringify(u))}
 function logout(){localStorage.removeItem("driveease_user");localStorage.removeItem("driveease_admin")}
 return {get,set,user,setUser,logout,defaults};
})();