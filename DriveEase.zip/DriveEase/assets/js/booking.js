document.addEventListener("DOMContentLoaded",()=>{
 const form=document.querySelector("#bookingForm");if(!form)return;const params=new URLSearchParams(location.search),id=Number(params.get("id")||sessionStorage.getItem("driveease_selectedCar")||1),car=DriveStore.get("cars").find(c=>c.id===id)||DriveStore.get("cars")[0];const money=n=>"₹"+Number(n).toLocaleString("en-IN");
 const carName=document.querySelector("#bookingCarName");if(carName)carName.textContent=car.name;const rate=document.querySelector("#dailyRate");if(rate)rate.textContent=money(car.price);
 const start=form.querySelector('[name="pickupDate"]'),end=form.querySelector('[name="returnDate"]');const today=new Date().toISOString().slice(0,10);start.min=today;end.min=today;
 function update(){if(!start.value||!end.value)return;let days=Math.ceil((new Date(end.value)-new Date(start.value))/86400000);if(days<1)days=0;document.querySelector("#rentalDays").textContent=days;document.querySelector("#totalPrice").textContent=money(days*car.price);return days}
 [start,end].forEach(x=>x.addEventListener("change",()=>{if(start.value){end.min=start.value;if(end.value<start.value)end.value=""}update()}));
 form.addEventListener("submit",e=>{e.preventDefault();if(!validateForm(form))return;let days=update();if(!days){end.classList.add("is-invalid");showToast("Choose a return date after pickup.");return}
 const user=DriveStore.user();const booking={id:"DE"+Date.now().toString().slice(-7),carId:car.id,carName:car.name,customer:form.fullName.value.trim(),email:form.email.value.trim(),phone:form.phone.value.trim(),location:form.location.value.trim(),pickupDate:start.value,returnDate:end.value,days,total:days*car.price,status:"Pending",createdAt:new Date().toISOString()};
 let bookings=DriveStore.get("bookings");bookings.unshift(booking);DriveStore.set("bookings",bookings);let customers=DriveStore.get("customers");if(!customers.some(c=>c.email===booking.email)){customers.push({name:booking.customer,email:booking.email,phone:booking.phone,status:"Active"});DriveStore.set("customers",customers)}
 sessionStorage.setItem("driveease_lastBooking",JSON.stringify(booking));location.href="booking-success.html";
 });
});