# DriveEase – Frontend Car Rental Website

A responsive multi-page car rental frontend built with HTML5, CSS3, JavaScript ES6, Bootstrap 5.3 and Bootstrap Icons.

## Pages
- `index.html` – public landing page
- `client/cars.html` – searchable/filterable fleet
- `client/car-details.html` – dynamic vehicle details
- `client/booking.html` – booking form with date, phone and email validation
- `client/booking-success.html` – confirmation view
- `client/account.html` – customer booking history and cancellation
- `client/login.html`, `client/register.html` – demo customer account flow
- `admin/login.html` – admin login
- `admin/dashboard.html` – overview and summary cards
- `admin/cars.html` – add/edit/delete vehicle inventory
- `admin/bookings.html` – booking status management
- `admin/customers.html` – customer directory
- `admin/settings.html` – editable business settings

The five primary client pages are Home, Cars, Car Details, Booking and Account. Login, registration and booking confirmation are supporting flows. The five admin management pages are Dashboard, Cars, Bookings, Customers and Settings, with a separate login page.

## Run
Open the project folder in VS Code and use the Live Server extension. You can also open `index.html` directly, but Live Server is recommended.

## Demo admin credentials
- Username: `admin`
- Password: `admin123`

## Important frontend-only note
All data is stored in the current browser's LocalStorage. This is a demonstration only, not secure authentication or production persistence. Passwords are not securely hashed, payments are not processed, and booking availability is not synchronized across devices. A real deployment needs a backend, database, secure authentication, server-side validation and a payment provider.
